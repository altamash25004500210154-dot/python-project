class Student:
    def __init__(self, name, roll_number):
        self.name = name
        self.roll_number = roll_number

    def display(self):
        print("Name:", self.name)
        print("Roll number:", self.roll_number)

student = Student("Altamash", 21)
student.display()
