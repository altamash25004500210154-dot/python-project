class BankAccount:
    def __init__(self, holder, balance):
        self.holder = holder
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount

    def show_balance(self):
        print("Account holder:", self.holder)
        print("Balance:", self.balance)

account = BankAccount("Altamash", 1000)
account.deposit(500)
account.show_balance()
