# Semester 3 Python Practical Programs

15 beginner-friendly Python programs covering **Strings**, **Functions**, and **Object-Oriented Programming (OOP)**.

The examples use the name **Altamash** where a person's name is needed. All `.py` files are standalone and have no code comments or exception-handling examples.

## Programs

| Topic | File | Concept |
|---|---|---|
| Strings | `strings/01_string_length.py` | Length of a string |
| Strings | `strings/02_string_reverse.py` | Reverse a string |
| Strings | `strings/03_string_palindrome.py` | Check palindrome |
| Strings | `strings/04_count_vowels.py` | Count vowels |
| Strings | `strings/05_count_words.py` | Count words |
| Functions | `functions/06_greeting_function.py` | Function with parameter |
| Functions | `functions/07_add_two_numbers.py` | Function with return value |
| Functions | `functions/08_even_or_odd.py` | Even or odd using a function |
| Functions | `functions/09_factorial_function.py` | Factorial using a function |
| Functions | `functions/10_largest_of_three.py` | Largest of three numbers |
| OOP | `oops/11_student_class.py` | Class, object and constructor |
| OOP | `oops/12_rectangle_area.py` | Method to calculate area |
| OOP | `oops/13_bank_account.py` | Object state and deposit method |
| OOP | `oops/14_employee_class.py` | Employee class and method |
| OOP | `oops/15_simple_inheritance.py` | Basic single inheritance |

## How to run

Install Python 3, open the project folder in a terminal and run a file, for example:

```bash
python strings/01_string_length.py
python functions/06_greeting_function.py
python oops/11_student_class.py
```

## Upload to GitHub

Unzip this project, create a GitHub repository, and upload `README.md` plus the `strings`, `functions`, and `oops` folders.
