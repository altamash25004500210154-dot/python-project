name = "Altamash"
print("Original name:", name)
print("Reversed name:", name[::-1])
