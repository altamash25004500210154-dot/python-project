name = "Altamash"
print("Name:", name)
print("Length:", len(name))
