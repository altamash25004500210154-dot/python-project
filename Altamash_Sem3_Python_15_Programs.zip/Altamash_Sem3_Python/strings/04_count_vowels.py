sentence = "Altamash is learning Python"
count = 0
for letter in sentence.lower():
    if letter in "aeiou":
        count += 1
print("Sentence:", sentence)
print("Number of vowels:", count)
