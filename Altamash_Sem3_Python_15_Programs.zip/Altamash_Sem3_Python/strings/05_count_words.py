sentence = "Altamash likes Python programming"
words = sentence.split()
print("Sentence:", sentence)
print("Number of words:", len(words))
