def add_numbers(a, b):
    return a + b

result = add_numbers(15, 25)
print("Sum:", result)
