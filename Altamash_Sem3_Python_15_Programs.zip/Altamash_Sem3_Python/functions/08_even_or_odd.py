def check_number(number):
    if number % 2 == 0:
        print(number, "is even")
    else:
        print(number, "is odd")

check_number(17)
